let lc = document.getElementById("loanCalculatorContent");

function siInputCollector(){
    const p = getInput('principal');
    let r = getInput('rate');
    r = r/100;
    const t = getInput('time');
    siCalculator(p, r, t);
}

function getInput(position){
    let num = prompt(`Type in the ${position}`)
    while(
        num === undefined ||
        num === "" ||
        isNaN(num) ||
        parseInt(num) < 1
    ) {
        alert(`Kindly type in a valid ${position}. It must be a number`);
        num = prompt(`Type in the ${position}`);
    }
    return num;
}

function siCalculator(p, r, t){
    const si = p * r * t ;
    const parameters = document.createElement("p");
    parameters.textContent = `The principal is ${p}, the rate is ${r}, the time is ${t} years`;
    const content = document.createElement("p");
    content.textContent = `${p} x ${r} x ${t} = ${si}`;
    const simpleInterest = document.createElement("p");
    simpleInterest.textContent = `Therefore the simple interest is ${si}`;
    lc.appendChild(parameters);
    lc.appendChild(content);
    lc.appendChild(simpleInterest);
}

function ciInputCollector(){
    const p = getInput('principal');
    let r = getInput('rate');
    r = r/100;
    const t = getInput('time');
    const n = getInput('compounding frequency per time period');
    ciCalculator(p, r, t, n);
}
  
function ciCalculator(p, r, t, n){
    const a = p * (1 + r/n) ** (n*t);
    const ci = a - p;
    const parameters = document.createElement("p");
    parameters.textContent = `The principal is ${p}, the rate is ${r}, the time is ${t} years, and the compounding frequency is ${n} times per year`;
    const content = document.createElement("p");
    content.textContent = `${p} ( 1 + ${r}/${n} )${n*t} = ${a}`;
    const compoundInterest = document.createElement("p");
    compoundInterest.textContent = `Therefore the compound interest is ${ci}`;
    lc.appendChild(parameters);
    lc.appendChild(content);
    lc.appendChild(compoundInterest);
}
  